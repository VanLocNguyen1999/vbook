load('config.js');
function execute() {
    return Response.success([
        {title: "Võ Hiệp Tiên Hiệp", input: "sort_wuxia", script: "gen.js"},
    ]);
}
