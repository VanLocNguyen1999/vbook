load('config.js');
function execute() {
    return Response.success([
        {title: "Võ Hiệp Tiên Hiệp", input: "https://m.yunxuange.org/yxg/sort_wuxia.html", script: "gen.js"},
    ]);
}
